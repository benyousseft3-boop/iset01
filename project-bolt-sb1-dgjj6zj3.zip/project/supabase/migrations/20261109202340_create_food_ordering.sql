/*
# Food ordering for students (Mekla & Restos)

1. New Tables
- `food_venues`: restaurants, pizzerias and snack bars around ISET Djerba.
  - `id` (uuid, primary key, fixed values for seeded rows)
  - `name`, `category` (Restaurant, Pizzeria or Snack), `area`, `description`, `image_url`
  - `opens_at` / `closes_at` (time): opening hours used for the "Ouvert maintenant" badge
  - `delivers_to_campus` (boolean): offers delivery to the ISET campus
  - `student_price` (boolean): offers student prices
- `food_items`: dishes and menu lines of each venue.
  - `venue_id` (references food_venues), `name`, `description`, `category`, `price_dt`, `image_url`
  - `available` (boolean): hides a dish without deleting it
- `food_orders`: orders placed by students.
  - `venue_id`, `customer_name`, `customer_phone`, `fulfilment` (pickup or campus_delivery)
  - `items` (jsonb): snapshot of the ordered lines with names and unit prices
  - `delivery_fee_dt`, `total_dt`, `status`, `created_at`

2. Functions
- `place_food_order(venue, name, phone, fulfilment, items)`: validates the order, recalculates every price from the menu on the server, adds the campus delivery fee when relevant, and records the order. It returns the order id and the total.

3. Security
- Row level security enabled on all three tables.
- Visitors can read venues and dishes (public catalogue, no sign-in in this app).
- Orders are never readable or writable directly from the browser; they can only be created through `place_food_order`.
- The function validates the name, phone number, quantities (1 to 20) and only accepts dishes that are available at the chosen venue.

4. Important notes
- Seeded rows use fixed ids and `ON CONFLICT DO NOTHING`, so re-running this migration does not duplicate them.
- The campus delivery fee is 2 DT.
*/

CREATE TABLE IF NOT EXISTS food_venues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL CHECK (category IN ('Restaurant', 'Pizzeria', 'Snack')),
  area text NOT NULL,
  description text NOT NULL,
  image_url text NOT NULL,
  opens_at time NOT NULL,
  closes_at time NOT NULL,
  delivers_to_campus boolean NOT NULL DEFAULT false,
  student_price boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS food_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id uuid NOT NULL REFERENCES food_venues(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text NOT NULL,
  category text NOT NULL,
  price_dt numeric(7,3) NOT NULL CHECK (price_dt > 0),
  image_url text NOT NULL,
  available boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS food_items_venue_id_idx ON food_items (venue_id);

CREATE TABLE IF NOT EXISTS food_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id uuid NOT NULL REFERENCES food_venues(id),
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  fulfilment text NOT NULL CHECK (fulfilment IN ('pickup', 'campus_delivery')),
  items jsonb NOT NULL,
  delivery_fee_dt numeric(7,3) NOT NULL DEFAULT 0,
  total_dt numeric(8,3) NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE food_venues ENABLE ROW LEVEL SECURITY;
ALTER TABLE food_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE food_orders ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON food_venues, food_items TO anon, authenticated;

DROP POLICY IF EXISTS "public_select_food_venues" ON food_venues;
CREATE POLICY "public_select_food_venues" ON food_venues FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "public_select_food_items" ON food_items;
CREATE POLICY "public_select_food_items" ON food_items FOR SELECT
  TO anon, authenticated USING (true);

INSERT INTO food_venues (id, name, category, area, description, image_url, opens_at, closes_at, delivers_to_campus, student_price) VALUES
  ('9c4e7a10-0000-4c00-9000-000000000001', 'Chez Moktar', 'Restaurant', 'Midoun', 'Cuisine tunisienne familiale, couscous et grillades préparés à la commande, très appréciée des habitués de Midoun.', 'https://images.pexels.com/photos/21625301/pexels-photo-21625301.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', '12:00', '23:00', false, false),
  ('9c4e7a10-0000-4c00-9000-000000000002', 'Matterello Pizza', 'Pizzeria', 'Houmt Souk', 'Petite pizzeria au cœur de Houmt Souk, pizzas généreuses cuites au four et prix doux pour les étudiants.', 'https://images.pexels.com/photos/10802332/pexels-photo-10802332.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', '11:00', '23:30', true, true),
  ('9c4e7a10-0000-4c00-9000-000000000003', 'Brik Belgasem', 'Snack', 'Houmt Souk', 'Snack de rue historique de Houmt Souk : lablabi, brik et sandwichs rapides pour un repas sur le pouce.', 'https://images.pexels.com/photos/33597401/pexels-photo-33597401.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', '06:00', '22:00', true, true),
  ('9c4e7a10-0000-4c00-9000-000000000004', 'Uncle Ali''s Fish', 'Restaurant', 'Midoun', 'Restaurant de poisson grillé et fritures, une des adresses les plus connues de l''île pour les repas entre amis.', 'https://images.pexels.com/photos/10907106/pexels-photo-10907106.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', '12:00', '23:00', false, false)
ON CONFLICT (id) DO NOTHING;

INSERT INTO food_items (id, venue_id, name, description, category, price_dt, image_url, sort_order) VALUES
  ('9c4e7a20-0000-4c00-9000-000000000101', '9c4e7a10-0000-4c00-9000-000000000001', 'Couscous à l''agneau', 'Semoule fine, viande d''agneau et légumes de saison, bouillon maison', 'Plat du jour', 16.000, 'https://images.pexels.com/photos/21625301/pexels-photo-21625301.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 1),
  ('9c4e7a20-0000-4c00-9000-000000000102', '9c4e7a10-0000-4c00-9000-000000000001', 'Couscous aux légumes', 'Couscous traditionnel avec courgettes, carottes et pois chiches', 'Plat du jour', 12.000, 'https://images.pexels.com/photos/1618929/pexels-photo-1618929.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 2),
  ('9c4e7a20-0000-4c00-9000-000000000103', '9c4e7a10-0000-4c00-9000-000000000001', 'Chorba frik', 'Soupe traditionnelle au blé concassé et à la menthe', 'Entrée', 5.000, 'https://images.pexels.com/photos/29850843/pexels-photo-29850843.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 3),
  ('9c4e7a20-0000-4c00-9000-000000000201', '9c4e7a10-0000-4c00-9000-000000000002', 'Pizza margherita', 'Tomate, mozzarella et basilic, pâte cuite au feu de bois', 'Pizza', 12.000, 'https://images.pexels.com/photos/10802332/pexels-photo-10802332.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 1),
  ('9c4e7a20-0000-4c00-9000-000000000202', '9c4e7a10-0000-4c00-9000-000000000002', 'Pizza 4 fromages', 'Mozzarella, gorgonzola, parmesan et chèvre', 'Pizza', 15.000, 'https://images.pexels.com/photos/17932142/pexels-photo-17932142.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 2),
  ('9c4e7a20-0000-4c00-9000-000000000203', '9c4e7a10-0000-4c00-9000-000000000002', 'Pizza thon', 'Thon, oignons, olives et mozzarella', 'Pizza', 14.000, 'https://images.pexels.com/photos/31596394/pexels-photo-31596394.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 3),
  ('9c4e7a20-0000-4c00-9000-000000000301', '9c4e7a10-0000-4c00-9000-000000000003', 'Lablabi', 'Pois chiches, pain émietté, harissa, cumin et œuf', 'Plat du jour', 3.500, 'https://images.pexels.com/photos/33597401/pexels-photo-33597401.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 1),
  ('9c4e7a20-0000-4c00-9000-000000000302', '9c4e7a10-0000-4c00-9000-000000000003', 'Sandwich grillé', 'Pain grillé garni de fromage fondu et de légumes frais', 'Sandwich', 5.000, 'https://images.pexels.com/photos/1885578/pexels-photo-1885578.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 2),
  ('9c4e7a20-0000-4c00-9000-000000000303', '9c4e7a10-0000-4c00-9000-000000000003', 'Sandwich mixte frites', 'Sandwich généreux accompagné de frites maison', 'Sandwich', 4.500, 'https://images.pexels.com/photos/29954941/pexels-photo-29954941.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 3),
  ('9c4e7a20-0000-4c00-9000-000000000401', '9c4e7a10-0000-4c00-9000-000000000004', 'Poisson grillé', 'Poisson du jour grillé, salade et citron', 'Plat du jour', 25.000, 'https://images.pexels.com/photos/10907106/pexels-photo-10907106.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 1),
  ('9c4e7a20-0000-4c00-9000-000000000402', '9c4e7a10-0000-4c00-9000-000000000004', 'Calamars frits', 'Anneaux de calamars croustillants et sauce citronnée', 'Plat', 18.000, 'https://images.pexels.com/photos/8250284/pexels-photo-8250284.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 2),
  ('9c4e7a20-0000-4c00-9000-000000000403', '9c4e7a10-0000-4c00-9000-000000000004', 'Poisson frit et frites', 'Filets de poisson frits avec frites et salade fraîche', 'Plat', 14.000, 'https://images.pexels.com/photos/19034915/pexels-photo-19034915.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 3)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS food_orders_placeholder_guard (id integer);
DROP TABLE IF EXISTS food_orders_placeholder_guard;
