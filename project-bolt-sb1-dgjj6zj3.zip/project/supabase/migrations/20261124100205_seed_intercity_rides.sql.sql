/*
# Seed intercity student rides (Tunis & Sfax)

1. Purpose
- Add realistic intercity ride offers that ISET Djerba students actually take,
  alongside the existing local rides (Houmt Souk / Midoun / Ajim -> ISET Djerba).

2. Modified Tables
- `ride_offers`: 6 new rows inserted (no schema change).
  - Djerba <-> Tunis at 40 DT / trip, within the realistic 35-45 DT range.
  - Djerba <-> Sfax at 22-25 DT / trip, within the realistic 20-28 DT range.
  - Each row carries a departure time, days/frequency label, note/contact and seats left.

3. Idempotency
- Rows use fixed UUIDs (continuing the existing `5a2e9b10-…` scheme) with
  `ON CONFLICT DO NOTHING`, so re-running the migration never duplicates data.

4. Security
- No security change: `ride_offers` already has RLS enabled with a public
  SELECT policy and anon/authenticated CRUD grants from earlier migrations.
*/

INSERT INTO ride_offers (id, origin, destination, departure_time, days_label, note, seats_left, price_dt) VALUES
  ('5a2e9b10-0005-4b00-9000-000000000005', 'Djerba (Houmt Souk)', 'Tunis', '05:30', 'Ven & Dim', 'Départ station de louages Houmt Souk, arrivée Moncef Bey. Réservation par WhatsApp la veille.', 3, 40),
  ('5a2e9b10-0006-4b00-9000-000000000006', 'Tunis', 'Djerba (Houmt Souk)', '14:00', 'Ven & Dim', 'Retour vers Djerba après le week-end. Bagages acceptés, étudiants prioritaires.', 3, 40),
  ('5a2e9b10-0007-4b00-9000-000000000007', 'Djerba (Houmt Souk)', 'Sfax', '07:00', 'Lun & Jeu', 'Louage confortable, pause café à Gabès incluse. Contact : 24 555 010.', 4, 25),
  ('5a2e9b10-0008-4b00-9000-000000000008', 'Sfax', 'Djerba (Houmt Souk)', '16:30', 'Lun & Jeu', 'Départ gare de louages Sfax, arrivée Houmt Souk en soirée.', 4, 25),
  ('5a2e9b10-0009-4b00-9000-000000000009', 'Midoun', 'Tunis', '06:15', 'Sam', 'Départ centre-ville Midoun. Idéal pour les week-ends de révision à Tunis.', 2, 42),
  ('5a2e9b10-000a-4b00-9000-00000000000a', 'Djerba (Ajim)', 'Sfax', '06:45', 'Mar', 'Trajet direct Ajim -> Sfax, bagages acceptés. Contact : 98 443 220.', 3, 22)
ON CONFLICT (id) DO NOTHING;
