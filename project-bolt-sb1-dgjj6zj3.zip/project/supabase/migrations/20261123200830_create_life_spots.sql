/*
# Add study spots and practical services

1. New Tables
- `life_spots`: study cafés, coworking spaces and practical services around ISET Djerba.
  - `id` (uuid, primary key)
  - `name`, `category` ('Etude' or 'Service'), `area`, `description`
  - `price_label` (short text, e.g. 'Wi-Fi gratuit', 'Impression 0,400 DT')
  - `features` (text[]): badges such as Wi-Fi, prises, imprimante
  - `image_url` (text): cover photograph
  - `maps_url` (text): Google Maps search link
  - `student_discount` (boolean): student discount or student price
  - `sort_order` (integer)

2. Security
- Row level security enabled; public read only (`anon`, `authenticated`), no browser writes.
- Grants limited to SELECT for the two public roles.

3. Important notes
- Seeded rows use fixed UUIDs with ON CONFLICT DO NOTHING, so re-running the migration does not duplicate them.
- Categories: 'Etude' covers cafés d'étude and coworking; 'Service' covers imprimeries, photocopie, reliure, papeterie, réparations.
- Photographs are real Pexels image URLs already used or verified in this project.
- No existing tables are modified and no data is deleted.
*/

CREATE TABLE IF NOT EXISTS public.life_spots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL CHECK (category IN ('Etude', 'Service')),
  area text NOT NULL,
  description text NOT NULL,
  price_label text NOT NULL,
  features text[] NOT NULL DEFAULT '{}',
  image_url text NOT NULL,
  maps_url text NOT NULL DEFAULT '',
  student_discount boolean NOT NULL DEFAULT false,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.life_spots ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON public.life_spots TO anon, authenticated;

DROP POLICY IF EXISTS "public_select_life_spots" ON public.life_spots;
CREATE POLICY "public_select_life_spots" ON public.life_spots FOR SELECT
  TO anon, authenticated USING (true);

INSERT INTO public.life_spots (id, name, category, area, description, price_label, features, image_url, maps_url, student_discount, sort_order) VALUES
  ('9c4e7a30-0000-4c00-9000-000000000101', 'Café El Bahri', 'Etude', 'Houmt Souk', 'Café calme et spacieux, très prisé des étudiants pour réviser : prises à chaque table et ambiance discrète en semaine.', 'Réductions étudiants', ARRAY['Wi-Fi', 'Prises', 'Ambiance calme'], 'https://images.pexels.com/photos/1855214/pexels-photo-1855214.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://www.google.com/maps/search/?api=1&query=Cafe+El+Bahri+Houmt+Souk+Djerba', true, 1),
  ('9c4e7a30-0000-4c00-9000-000000000102', 'Espace Coworking Djerba', 'Etude', 'Houmt Souk', 'Espace de coworking avec grandes tables, fauteuils confortables et coins silencieux, idéal pour les travaux de groupe.', 'Tarif étudiant journée', ARRAY['Wi-Fi', 'Prises', 'Climatisation'], 'https://images.pexels.com/photos/3183150/pexels-photo-3183150.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://www.google.com/maps/search/?api=1&query=coworking+space+Houmt+Souk+Djerba', true, 2),
  ('9c4e7a30-0000-4c00-9000-000000000103', 'Bibliothèque municipale', 'Etude', 'Houmt Souk', 'Bibliothèque publique tranquille avec salles de lecture, ouverte à tous les étudiants gratuitement.', 'Gratuit', ARRAY['Wi-Fi', 'Silence', 'Salles de lecture'], 'https://images.pexels.com/photos/590493/pexels-photo-590493.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://www.google.com/maps/search/?api=1&query=bibliotheque+Houmt+Souk+Djerba', false, 3),
  ('9c4e7a30-0000-4c00-9000-000000000201', 'Copy Center ISET', 'Service', 'À côté du campus', 'Imprimerie de proximité : impression et photocopie noir et couleur, reliure, plastification et fournitures de papeterie.', 'Impression dès 0,400 DT', ARRAY['Impression', 'Reliure', 'Papeterie'], 'https://images.pexels.com/photos/3243/photographing-a-pencil.jpg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://www.google.com/maps/search/?api=1&query=Copy+Center+ISET+Djerba', true, 1),
  ('9c4e7a30-0000-4c00-9000-000000000202', 'Service Photo & Bureautique', 'Service', 'Houmt Souk', 'Impressions photo,扫scans de documents, reliures et petites réparations de matériel informatique.', 'Scan dès 0,500 DT', ARRAY['Impression', 'Scan', 'Réparations'], 'https://images.pexels.com/photos/267569/pexels-photo-267569.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://www.google.com/maps/search/?api=1&query=imprimerie+Houmt+Souk+Djerba', false, 2),
  ('9c4e7a30-0000-4c00-9000-000000000203', 'Librairie-Papeterie El Kitab', 'Service', 'Houmt Souk', 'Papeterie et librairie bien achalandée : cahiers, classeurs, stylos et tout le nécessaire pour l''année universitaire.', 'Remise étudiants', ARRAY['Papeterie', 'Fournitures', 'Livres'], 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&h=650&w=940', 'https://www.google.com/maps/search/?api=1&query=librairie+papeterie+Houmt+Souk+Djerba', true, 3)
ON CONFLICT (id) DO NOTHING;
