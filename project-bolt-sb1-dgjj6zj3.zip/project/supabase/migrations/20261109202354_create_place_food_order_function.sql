/*
# Secure food order placement

1. Functions
- `place_food_order(venue, name, phone, fulfilment, items)`: creates an order for a venue.
  - Checks the customer name (2 to 80 characters) and phone number (8 to 20 digits, spaces or +).
  - Checks the fulfilment choice: pickup or campus delivery.
  - Campus delivery is only accepted by venues that deliver to the campus. It adds a 2 DT delivery fee.
  - Each line must be an available dish of that venue, with a quantity from 1 to 20.
  - Prices are read from the menu on the server, never taken from the browser.
  - Returns the new order id and the total in dinars.

2. Security
- The function runs with the owner's rights so it can record the order, while visitors cannot write to the orders table directly.
- Only anonymous and signed-in visitors can call it; the function's search path is fixed to the public schema.

3. Important notes
- Orders are stored with a snapshot of names and unit prices, so later menu changes do not alter past orders.
*/

CREATE OR REPLACE FUNCTION place_food_order(
  p_venue_id uuid,
  p_customer_name text,
  p_customer_phone text,
  p_fulfilment text,
  p_items jsonb
)
RETURNS TABLE (order_id uuid, total_dt numeric)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_item jsonb;
  v_item_id uuid;
  v_quantity integer;
  v_name text;
  v_price numeric(7,3);
  v_lines jsonb := '[]'::jsonb;
  v_subtotal numeric(8,3) := 0;
  v_fee numeric(7,3) := 0;
  v_order_id uuid;
BEGIN
  IF char_length(btrim(p_customer_name)) < 2 OR char_length(btrim(p_customer_name)) > 80 THEN
    RAISE EXCEPTION 'invalid_name';
  END IF;

  IF btrim(p_customer_phone) !~ '^[0-9+ ]{8,20}$' THEN
    RAISE EXCEPTION 'invalid_phone';
  END IF;

  IF p_fulfilment NOT IN ('pickup', 'campus_delivery') THEN
    RAISE EXCEPTION 'invalid_fulfilment';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM food_venues v WHERE v.id = p_venue_id) THEN
    RAISE EXCEPTION 'unknown_venue';
  END IF;

  IF p_fulfilment = 'campus_delivery'
     AND NOT EXISTS (SELECT 1 FROM food_venues v WHERE v.id = p_venue_id AND v.delivers_to_campus) THEN
    RAISE EXCEPTION 'no_campus_delivery';
  END IF;

  IF jsonb_typeof(p_items) IS DISTINCT FROM 'array' OR jsonb_array_length(p_items) = 0 THEN
    RAISE EXCEPTION 'empty_order';
  END IF;

  FOR v_item IN SELECT * FROM jsonb_array_elements(p_items) LOOP
    v_item_id := (v_item->>'item_id')::uuid;
    v_quantity := (v_item->>'quantity')::integer;

    IF v_quantity IS NULL OR v_quantity < 1 OR v_quantity > 20 THEN
      RAISE EXCEPTION 'invalid_quantity';
    END IF;

    SELECT i.name, i.price_dt INTO v_name, v_price
    FROM food_items i
    WHERE i.id = v_item_id AND i.venue_id = p_venue_id AND i.available;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'unavailable_item';
    END IF;

    v_subtotal := v_subtotal + v_price * v_quantity;
    v_lines := v_lines || jsonb_build_object(
      'item_id', v_item_id,
      'name', v_name,
      'quantity', v_quantity,
      'unit_price_dt', v_price
    );
  END LOOP;

  IF p_fulfilment = 'campus_delivery' THEN
    v_fee := 2.000;
  END IF;

  INSERT INTO food_orders (venue_id, customer_name, customer_phone, fulfilment, items, delivery_fee_dt, total_dt)
  VALUES (
    p_venue_id,
    btrim(p_customer_name),
    btrim(p_customer_phone),
    p_fulfilment,
    v_lines,
    v_fee,
    v_subtotal + v_fee
  )
  RETURNING id INTO v_order_id;

  RETURN QUERY SELECT v_order_id, v_subtotal + v_fee;
END;
$$;

REVOKE EXECUTE ON FUNCTION place_food_order(uuid, text, text, text, jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION place_food_order(uuid, text, text, text, jsonb) TO anon, authenticated;
