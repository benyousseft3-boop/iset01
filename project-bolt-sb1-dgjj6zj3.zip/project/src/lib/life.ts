import { supabase } from './supabase';

export type LifeSpotCategory = 'Etude' | 'Service';

export type LifeSpot = {
  id: string;
  name: string;
  category: LifeSpotCategory;
  area: string;
  description: string;
  price_label: string;
  features: string[];
  image_url: string;
  maps_url: string;
  student_discount: boolean;
  sort_order: number;
};

export async function fetchLifeSpots(): Promise<LifeSpot[]> {
  if (!supabase) throw new Error('La connexion à IsetHub est indisponible.');
  const { data, error } = await supabase
    .from('life_spots')
    .select('id, name, category, area, description, price_label, features, image_url, maps_url, student_discount, sort_order')
    .order('sort_order');
  if (error) throw error;
  return (data ?? []) as LifeSpot[];
}
