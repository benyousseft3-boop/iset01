import { supabase } from './supabase';

export type FoodCategory = 'Restaurant' | 'Pizzeria' | 'Snack';
export type Fulfilment = 'pickup' | 'campus_delivery';

export const CAMPUS_DELIVERY_FEE_DT = 2;

export type FoodItem = {
  id: string;
  name: string;
  description: string;
  category: string;
  price_dt: number;
  image_url: string;
  available: boolean;
  sort_order: number;
};

export type FoodVenue = {
  id: string;
  name: string;
  category: FoodCategory;
  area: string;
  description: string;
  image_url: string;
  opens_at: string;
  closes_at: string;
  delivers_to_campus: boolean;
  student_price: boolean;
  maps_url: string;
  food_items: FoodItem[];
};

export type OrderLine = { itemId: string; quantity: number };

const venueColumns = `
  id, name, category, area, description, image_url, opens_at, closes_at, delivers_to_campus, student_price, maps_url,
  food_items(id, name, description, category, price_dt, image_url, available, sort_order)
`;

export async function fetchFoodVenues(): Promise<FoodVenue[]> {
  if (!supabase) throw new Error('La connexion à IsetHub est indisponible.');
  const { data, error } = await supabase.from('food_venues').select(venueColumns).order('name');
  if (error) throw error;
  return ((data ?? []) as FoodVenue[]).map((venue) => ({
    ...venue,
    food_items: [...venue.food_items].sort((a, b) => a.sort_order - b.sort_order),
  }));
}

export async function placeFoodOrder(input: {
  venueId: string;
  customerName: string;
  customerPhone: string;
  fulfilment: Fulfilment;
  lines: OrderLine[];
}): Promise<{ orderId: string; totalDt: number }> {
  if (!supabase) throw new Error('La connexion à IsetHub est indisponible.');
  const { data, error } = await supabase.rpc('place_food_order', {
    p_venue_id: input.venueId,
    p_customer_name: input.customerName,
    p_customer_phone: input.customerPhone,
    p_fulfilment: input.fulfilment,
    p_items: input.lines.map((line) => ({ item_id: line.itemId, quantity: line.quantity })),
  });
  if (error) throw new Error(orderErrorMessage(error.message));

  const row = Array.isArray(data) ? data[0] : null;
  if (!row || typeof row.order_id !== 'string') throw new Error(orderErrorMessage(''));
  return { orderId: row.order_id, totalDt: Number(row.total_dt) };
}

const orderErrors: Record<string, string> = {
  invalid_name: 'Indique ton prénom ou ton nom (2 caractères minimum).',
  invalid_phone: 'Le numéro de téléphone semble incorrect.',
  no_campus_delivery: 'Ce restaurant ne livre pas sur le campus.',
  unavailable_item: 'Un plat de ta commande n’est plus disponible. Mets ton panier à jour.',
  invalid_quantity: 'Les quantités doivent être entre 1 et 20.',
};

function orderErrorMessage(message: string) {
  const match = Object.keys(orderErrors).find((code) => message.includes(code));
  return match ? orderErrors[match] : 'La commande n’a pas pu être envoyée. Réessaie dans un instant.';
}

function toMinutes(time: string) {
  const [hours, minutes] = time.split(':').map(Number);
  return hours * 60 + minutes;
}

export function isOpenNow(opensAt: string, closesAt: string, now: Date = new Date()) {
  const current = now.getHours() * 60 + now.getMinutes();
  const opens = toMinutes(opensAt);
  const closes = toMinutes(closesAt);
  return opens <= closes ? current >= opens && current < closes : current >= opens || current < closes;
}

export function formatDinar(value: number) {
  const label = Number.isInteger(value) ? String(value) : value.toFixed(3).replace('.', ',');
  return `${label} DT`;
}

export function formatTime(time: string) {
  return time.slice(0, 5);
}
