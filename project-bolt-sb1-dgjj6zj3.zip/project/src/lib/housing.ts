import { supabase } from './supabase';

export type HousingType = 'Studio' | 'Appartement' | 'Colocation';

export type HousingListing = {
  id: string;
  title: string;
  property_type: HousingType;
  neighborhood: string;
  rooms: number;
  price_dt: number;
  available_label: string;
  description: string;
  image_url: string;
  amenities: string[];
  distance_to_iset: string;
};

const housingColumns = 'id, title, property_type, neighborhood, rooms, price_dt, available_label, description, image_url, amenities, distance_to_iset';

export async function fetchHousingListings(): Promise<HousingListing[]> {
  if (!supabase) throw new Error('La connexion à IsetHub est indisponible.');
  const { data, error } = await supabase
    .from('housing_listings')
    .select(housingColumns)
    .order('price_dt', { ascending: true });
  if (error) throw error;
  return (data ?? []) as HousingListing[];
}
