import { BadgeCheck, ExternalLink, MapPin } from 'lucide-react';
import type { LifeSpot } from '@/lib/life';

type LifeSpotCardProps = {
  spot: LifeSpot;
};

export function LifeSpotCard({ spot }: LifeSpotCardProps) {
  return (
    <article className="group flex flex-col overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#126cb1]/10">
      <div className="relative aspect-[16/10] overflow-hidden bg-slate-100">
        <img
          src={spot.image_url}
          alt={spot.name}
          loading="lazy"
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
        {spot.student_discount && (
          <span className="absolute left-3 top-3 inline-flex items-center gap-1.5 rounded-full bg-[#fab757] px-3 py-1 text-xs font-black text-[#021d33] shadow">
            <BadgeCheck size={13} /> Prix étudiant
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-5">
        <div className="flex items-start justify-between gap-3">
          <h3 className="text-lg font-black leading-snug text-[#021d33]">{spot.name}</h3>
          <span className="shrink-0 rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">
            {spot.category === 'Etude' ? 'Étude' : 'Service'}
          </span>
        </div>
        <span className="mt-3 flex w-fit items-center gap-1.5 text-sm font-semibold text-slate-500">
          <MapPin size={15} className="text-[#126cb1]" /> {spot.area}
        </span>
        <p className="mt-3 line-clamp-2 text-sm leading-6 text-slate-500">{spot.description}</p>

        <div className="mt-4 flex flex-wrap gap-2">
          {spot.features.map((feature) => (
            <span key={feature} className="rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-bold text-slate-700">
              {feature}
            </span>
          ))}
        </div>

        <div className="mt-auto flex items-center justify-between gap-3 pt-5">
          <span className="text-sm font-black text-[#126cb1]">{spot.price_label}</span>
          {spot.maps_url && (
            <a
              href={spot.maps_url}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 text-sm font-black text-slate-600 transition hover:text-[#126cb1]"
            >
              <ExternalLink size={15} /> Maps
            </a>
          )}
        </div>
      </div>
    </article>
  );
}
