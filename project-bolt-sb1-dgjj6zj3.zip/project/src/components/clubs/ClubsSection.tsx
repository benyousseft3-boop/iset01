import { useEffect, useState } from 'react';
import { CalendarDays, RotateCcw } from 'lucide-react';
import { fetchClubs, fetchUpcomingEvents, type Club, type ClubEvent } from '@/lib/clubs';
import { ClubAgenda } from './ClubAgenda';
import { ClubCard } from './ClubCard';
import { ClubDetailsDialog } from './ClubDetailsDialog';

type ClubsSectionProps = { notify: (message: string) => void };

export function ClubsSection({ notify }: ClubsSectionProps) {
  const [clubs, setClubs] = useState<Club[]>([]);
  const [events, setEvents] = useState<ClubEvent[]>([]);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [reloadKey, setReloadKey] = useState(0);
  const [joined, setJoined] = useState<Set<string>>(new Set());
  const [detailsClubId, setDetailsClubId] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    Promise.all([fetchClubs(), fetchUpcomingEvents()])
      .then(([clubList, eventList]) => {
        if (!active) return;
        setClubs(clubList);
        setEvents(eventList);
        setStatus('ready');
      })
      .catch(() => {
        if (active) setStatus('error');
      });
    return () => { active = false; };
  }, [reloadKey]);

  const toggleJoin = (club: Club) => {
    const isJoined = joined.has(club.id);
    setJoined((current) => {
      const next = new Set(current);
      if (isJoined) next.delete(club.id);
      else next.add(club.id);
      return next;
    });
    notify(isJoined ? 'Tu as quitté ' + club.name + '.' : 'Bienvenue dans ' + club.name + ' !');
  };

  const openClubId = (clubId: string) => setDetailsClubId(clubId);
  const detailsClub = clubs.find((club) => club.id === detailsClubId) ?? null;

  if (status === 'loading') {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, index) => (
          <div key={index} className="h-72 animate-pulse rounded-2xl border border-slate-200 bg-white" />
        ))}
      </div>
    );
  }

  if (status === 'error') {
    return (
      <div className="flex flex-col items-center rounded-2xl border border-red-100 bg-white p-10 text-center">
        <p className="font-black text-slate-700">Impossible de charger les clubs pour le moment.</p>
        <p className="mt-2 text-sm text-slate-400">Vérifie ta connexion puis réessaie.</p>
        <button
          onClick={() => { setStatus('loading'); setReloadKey((key) => key + 1); }}
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-[#126cb1] px-4 py-2.5 text-sm font-black text-white transition hover:bg-[#0f5b96]"
        >
          <RotateCcw size={16} /> Réessayer
        </button>
      </div>
    );
  }

  return (
    <>
      <section>
        <div className="mb-5 flex items-end justify-between">
          <h2 className="text-2xl font-black">Les clubs de l'ISET Djerba</h2>
          <span className="text-sm font-semibold text-slate-400">{clubs.length} clubs officiels</span>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {clubs.map((club) => (
            <ClubCard
              key={club.id}
              club={club}
              joined={joined.has(club.id)}
              onDetails={() => openClubId(club.id)}
              onToggleJoin={() => toggleJoin(club)}
            />
          ))}
        </div>
      </section>

      <section className="mt-16">
        <div className="mb-6 flex items-end justify-between gap-4">
          <div>
            <p className="text-sm font-black uppercase tracking-[.16em] text-[#126cb1]">Calendrier</p>
            <h2 className="mt-1 flex items-center gap-2 text-2xl font-black"><CalendarDays size={24} className="text-[#fab757]" /> Activités à venir</h2>
          </div>
        </div>
        <ClubAgenda events={events} clubs={clubs} onOpenClub={openClubId} notify={notify} />
      </section>

      {detailsClub && (
        <ClubDetailsDialog
          club={detailsClub}
          events={events.filter((event) => event.club_id === detailsClub.id)}
          joined={joined.has(detailsClub.id)}
          onToggleJoin={() => toggleJoin(detailsClub)}
          onClose={() => setDetailsClubId(null)}
        />
      )}
    </>
  );
}
