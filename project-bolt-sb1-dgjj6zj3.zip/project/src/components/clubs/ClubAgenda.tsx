import { useMemo, useState } from 'react';
import { CalendarDays, Check, Clock3, MapPin } from 'lucide-react';
import { formatEventParts, type Club, type ClubEvent } from '@/lib/clubs';
import { categoryStyles } from './clubStyles';

type ClubAgendaProps = {
  events: ClubEvent[];
  clubs: Club[];
  onOpenClub: (clubId: string) => void;
  notify: (message: string) => void;
};

export function ClubAgenda({ events, clubs, onOpenClub, notify }: ClubAgendaProps) {
  const [filterClubId, setFilterClubId] = useState<string | null>(null);
  const [reserved, setReserved] = useState<Set<string>>(new Set());

  const clubsById = useMemo(() => new Map(clubs.map((club) => [club.id, club])), [clubs]);
  const clubsWithEvents = useMemo(() => clubs.filter((club) => events.some((event) => event.club_id === club.id)), [clubs, events]);
  const visibleEvents = filterClubId ? events.filter((event) => event.club_id === filterClubId) : events;

  const toggleReservation = (event: ClubEvent) => {
    const isReserved = reserved.has(event.id);
    setReserved((current) => {
      const next = new Set(current);
      if (isReserved) next.delete(event.id);
      else next.add(event.id);
      return next;
    });
    notify(isReserved ? 'Réservation annulée.' : 'Place réservée pour « ' + event.title + ' ».');
  };

  return (
    <div>
      <div className="mb-6 flex flex-wrap gap-2">
        <FilterChip label="Tous les clubs" active={filterClubId === null} onClick={() => setFilterClubId(null)} />
        {clubsWithEvents.map((club) => (
          <FilterChip key={club.id} label={club.name} active={filterClubId === club.id} onClick={() => setFilterClubId(club.id)} />
        ))}
      </div>

      {visibleEvents.length === 0 ? (
        <div className="flex flex-col items-center rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
          <CalendarDays size={28} className="text-slate-300" />
          <p className="mt-4 text-sm font-semibold text-slate-400">Aucune activité prévue pour ce club pour le moment.</p>
        </div>
      ) : (
        <ol className="grid gap-4">
          {visibleEvents.map((event) => {
            const club = event.club_id ? clubsById.get(event.club_id) : undefined;
            const parts = formatEventParts(event.event_date);
            const isReserved = reserved.has(event.id);
            return (
              <li key={event.id} className="flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-[#b8dbf2] hover:shadow-md sm:flex-row sm:items-center">
                <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-2xl bg-[#fff4df] text-[#8a5300]">
                  <span className="text-[10px] font-black uppercase">{parts.month}</span>
                  <strong className="text-xl leading-none">{parts.day}</strong>
                </div>

                <div className="min-w-0 flex-1">
                  <div className="mb-1.5 flex flex-wrap items-center gap-2">
                    {club && (
                      <button onClick={() => onOpenClub(club.id)} className="text-xs font-black uppercase tracking-wider text-[#126cb1] hover:underline">
                        {club.name}
                      </button>
                    )}
                    {club?.categories.slice(0, 2).map((category) => (
                      <span key={category} className={`rounded-md px-2 py-0.5 text-[10px] font-black uppercase tracking-wider ${categoryStyles[category]}`}>{category}</span>
                    ))}
                  </div>
                  <h3 className="font-black">{event.title}</h3>
                  {event.description && <p className="mt-1 text-sm text-slate-500">{event.description}</p>}
                  <p className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs font-bold text-slate-400">
                    <span className="flex items-center gap-1 capitalize"><CalendarDays size={13} /> {parts.weekday}</span>
                    <span className="flex items-center gap-1"><Clock3 size={13} /> {parts.time}</span>
                    <span className="flex items-center gap-1"><MapPin size={13} /> {event.location}</span>
                  </p>
                </div>

                <button
                  onClick={() => toggleReservation(event)}
                  className={`inline-flex shrink-0 items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-black transition ${isReserved ? 'bg-[#e8f7f0] text-[#11704a]' : 'bg-[#126cb1] text-white hover:bg-[#0f5b96]'}`}
                >
                  {isReserved ? <><Check size={16} /> Place réservée</> : 'Réserver ma place'}
                </button>
              </li>
            );
          })}
        </ol>
      )}
    </div>
  );
}

function FilterChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-xl px-3 py-2 text-xs font-bold transition ${active ? 'bg-[#126cb1] text-white' : 'border border-slate-200 bg-white text-slate-500 hover:border-[#126cb1] hover:text-[#126cb1]'}`}
    >
      {label}
    </button>
  );
}
