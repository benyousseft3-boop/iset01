import { Check } from 'lucide-react';
import type { Club } from '@/lib/clubs';
import { categoryStyles } from './clubStyles';
import { ClubLogo } from './ClubLogo';

type ClubCardProps = {
  club: Club;
  joined: boolean;
  onDetails: () => void;
  onToggleJoin: () => void;
};

export function ClubCard({ club, joined, onDetails, onToggleJoin }: ClubCardProps) {
  const info: { label: string; value: string }[] = [];
  if (club.founded_year) info.push({ label: 'Année de création', value: String(club.founded_year) });
  if (club.president_name) info.push({ label: 'Responsable', value: club.president_name });
  if (club.academic_supervisor) info.push({ label: 'Responsable académique', value: club.academic_supervisor });

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:border-[#b8dbf2] hover:shadow-xl hover:shadow-[#126cb1]/10">
      <div className="flex items-start justify-between gap-3 p-6 pb-0">
        <ClubLogo club={club} className="h-14 w-14" iconSize={26} />
        <div className="flex flex-wrap justify-end gap-1.5">
          {club.categories.map((category) => (
            <span key={category} className={`rounded-md px-2 py-1 text-[10px] font-black uppercase tracking-wider ${categoryStyles[category]}`}>{category}</span>
          ))}
        </div>
      </div>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="text-lg font-black leading-snug">{club.name}</h3>
        <p className="mt-2 line-clamp-3 text-sm leading-6 text-slate-500">{club.description}</p>

        {info.length > 0 && (
          <dl className="mt-5 space-y-2.5 border-t border-slate-100 pt-4">
            {info.map((item) => (
              <div key={item.label} className="flex items-baseline justify-between gap-3 text-xs">
                <dt className="font-bold text-slate-400">{item.label}</dt>
                <dd className="text-right font-bold text-slate-700">{item.value}</dd>
              </div>
            ))}
          </dl>
        )}

        <div className="mt-auto flex flex-col gap-2 pt-6">
          <button
            onClick={onToggleJoin}
            className={`flex items-center justify-center gap-1.5 rounded-xl px-3 py-2.5 text-sm font-black transition ${joined ? 'bg-[#e8f7f0] text-[#11704a]' : 'bg-[#126cb1] text-white hover:bg-[#0f5b96]'}`}
          >
            {joined ? <><Check size={16} /> Tu es membre</> : 'Rejoindre le club'}
          </button>
          <button onClick={onDetails} className="rounded-xl px-3 py-2 text-sm font-bold text-slate-500 transition hover:bg-slate-50 hover:text-[#126cb1]">
            Détails du club
          </button>
        </div>
      </div>
    </article>
  );
}
