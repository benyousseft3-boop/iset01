import type { Club } from '@/lib/clubs';
import { getClubVisual } from './clubStyles';

type ClubLogoProps = {
  club: Club;
  className: string;
  iconSize: number;
};

export function ClubLogo({ club, className, iconSize }: ClubLogoProps) {
  if (club.logo_url) {
    return (
      <div className={`flex shrink-0 items-center justify-center overflow-hidden rounded-2xl border border-slate-200 bg-white p-1.5 shadow-sm ${className}`}>
        <img src={club.logo_url} alt={`Logo ${club.name}`} className="h-full w-full object-contain" />
      </div>
    );
  }

  const { icon: Icon, tile } = getClubVisual(club.slug);
  return (
    <div className={`flex shrink-0 items-center justify-center rounded-2xl text-white shadow-sm ${tile} ${className}`}>
      <Icon size={iconSize} />
    </div>
  );
}
