import { Clock, Users } from 'lucide-react';
import type { RideOffer } from '@/lib/rides';

type RideCardProps = {
  ride: RideOffer;
  onContact: () => void;
};

export function RideCard({ ride, onContact }: RideCardProps) {
  const full = ride.seats_left === 0;
  const time = ride.departure_time.slice(0, 5);

  return (
    <article className="flex flex-col rounded-[1.5rem] border border-slate-200 bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-[#126cb1]/10 sm:p-6">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-2 rounded-xl bg-[#eaf5fc] px-3 py-2 text-[#126cb1]">
          <Clock size={18} />
          <span className="text-2xl font-black tabular-nums leading-none text-[#126cb1]">{time}</span>
        </div>
        <span className="rounded-full bg-[#fab757] px-3 py-1.5 text-sm font-black text-[#021d33] shadow-sm">
          {ride.price_dt} DT / trajet
        </span>
      </div>

      <div className="mt-6 flex gap-4">
        <div className="flex flex-col items-center pt-1.5">
          <span className="h-3 w-3 rounded-full border-2 border-[#126cb1] bg-white" />
          <span className="my-1 w-px flex-1 bg-slate-200" />
          <span className="h-3 w-3 rounded-full bg-[#fab757]" />
        </div>
        <div className="flex min-w-0 flex-1 flex-col gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.14em] text-slate-400">Départ</p>
            <p className="truncate font-black text-[#021d33]">{ride.origin}</p>
          </div>
          <div>
            <p className="text-xs font-bold uppercase tracking-[.14em] text-slate-400">Arrivée</p>
            <p className="truncate font-black text-[#021d33]">{ride.destination}</p>
          </div>
        </div>
      </div>

      <p className="mt-5 text-sm leading-6 text-slate-500">{ride.note}</p>

      <div className="mt-5 flex flex-wrap items-center gap-2">
        <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-bold text-slate-600">{ride.days_label}</span>
        <span
          className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-bold ${full ? 'bg-red-50 text-red-700' : 'bg-emerald-50 text-emerald-700'}`}
        >
          <Users size={14} />
          {full ? 'Complet' : `${ride.seats_left} ${ride.seats_left > 1 ? 'places restantes' : 'place restante'}`}
        </span>
      </div>

      <button
        onClick={onContact}
        disabled={full}
        className="mt-6 h-11 w-full rounded-xl bg-[#126cb1] text-sm font-black text-white transition hover:bg-[#0f5b96] active:scale-[.98] disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-500"
      >
        {full ? 'Trajet complet' : 'Contacter'}
      </button>
    </article>
  );
}
